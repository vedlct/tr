<div class="col-lg-2">

    <div class="navbar">
        <ul>
            <li class="active" style="width: 100%"><a href="<?php echo base_url('Welcome/home') ?>"
                                                      target="">Home</a></li>

            <li style="width: 100%"><a href="<?php echo base_url('Welcome/details') ?>" target="">View</a></li>
            <li style="width: 100%"><a href="<?php echo base_url('Welcome/addclient') ?>" target="">Add Client</a></li>
            <li style="width: 100%"><a href="<?php echo base_url('Welcome/changepassword') ?>" target="">Change Password</a></li>
            <li style="width: 100%"><a href="<?php echo base_url('Welcome/logout') ?>" target="">Log Out</a></li>


        </ul>
    </div>
</div>